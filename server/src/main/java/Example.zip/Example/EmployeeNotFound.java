package Example;

public class EmployeeNotFound extends RuntimeException {

}
