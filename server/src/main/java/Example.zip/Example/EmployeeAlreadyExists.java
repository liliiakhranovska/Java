package Example;

public class EmployeeAlreadyExists extends RuntimeException {

}
